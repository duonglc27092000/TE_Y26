::-------------------------Set Env-------------------------------------
@echo off
:start
cd /d %~dp0
set name=%~n0
set spec1=0
set spec2=0
set spec3=0
set ERR_CODE=000000
if exist D:\SFCS\Info.bat call D:\SFCS\Info.bat
if exist D:\Config\CFG.bat call D:\Config\CFG.bat
call D:\log\testlog.bat start %name% %spec1% %spec2% %spec3% %ERR_CODE%

IF @%SFCSPPID:~0,3%==@481 GOTO PASS
IF @%SFCSPPID:~0,3%==@491 GOTO PASS

::-------------------------Get GCF LCD PIXEL-------------------------------
:GetGcfLCD
if exist D:\BURNIN\GCFEQU\GCF2SIZE.BAT call D:\BURNIN\GCFEQU\GCF2SIZE.BAT
if not defined Web_LCD_PIXEL CALL :ShowErrorTE TENG01 NGITEM.INI & goto GetGcfLCD
set GCFPIXEL=%Web_LCD_PIXEL%
echo %Web_LCD_PIXEL%

::-------------------------Get Local LCD PIXEL-------------------------------
:GetLocalLCD
cd /d %~dp0
if exist LocalLCD.log del LocalLCD.log
if exist Resolution.txt del Resolution.txt
wEDID64.exe >LocalLCD.log
ping 127.0.0.1 -n 2
if not exist LocalLCD.log CALL :ShowErrorTE TENG02 NGITEM.INI & goto GetGcfLCD
find /i "Max. Resolution" LocalLCD.log >Resolution.txt 
for /f "skip=2 tokens=2 delims=:" %%i in (Resolution.txt) do set Resolution=%%i
set LocalPIXEL=%Resolution: =%

::-------------------------Check PIXEL-------------------------------
:CheckPIXEL
if exist GCFPIXEL.txt del GCFPIXEL.txt
echo %GCFPIXEL%>GCFPIXEL.txt
find /i "%LocalPIXEL%" GCFPIXEL.txt
if NOT @%errorlevel%==@0 CALL :ShowErrorPD PDNG01 NGITEM.INI & goto GetGcfLCD

::-------------------------Result--------------------------------------
:PASS
CALL D:\UploadNgError.BAT Kiểm_tra_LCD_GCFEQU_LCD测试 PASS
cd /d %~dp0
call D:\log\testlog.bat pass %name% %GCFPIXEL% %LocalPIXEL% %spec3% %ERR_CODE%
echo The LCD in the order is %GCFPIXEL%
echo The LCD in the config is %LocalPIXEL%
echo GCF LCD PIXEL Test PASS
exit /b 0


:FAIL
CALL D:\UploadNgError.BAT Kiểm_tra_LCD_GCFEQU_LCD测试 FAIL
cd /d %~dp0
echo The LCD in the order is %GCFPIXEL%
echo The LCD in the config is %LocalPIXEL%
echo GCF LCD PIXEL Test FAIL
rem ShowError.exe LCDPIXEL.jpg
call D:\log\testlog.bat fail %name% %GCFPIXEL% %LocalPIXEL% %spec3% %ERR_CODE%
ping 127.0.0.1 -n 5
goto start
exit /b 1

:ShowErrorPD
CALL D:\UploadNgError.BAT Kiểm_tra_LCD_GCFEQU_LCD测试 FAIL
cd /d %~dp0
start D:\ShowErrorNew\ShowErrorPD.exe "Test :%name%" %1 %2
ping 127.0.0.1 -n 60
tasklist|find /i "ShowErrorPD.exe" & if errorlevel 0 taskkill /f /t /im "ShowErrorPD.exe"
goto :eof

:ShowErrorTE
CALL D:\UploadNgError.BAT Kiểm_tra_LCD_GCFEQU_LCD测试 FAIL
cd /d %~dp0
start D:\ShowErrorNew\ShowErrorTE.exe "Test :%name%" %1 %2
ping 127.0.0.1 -n 20
tasklist|find /i "ShowErrorTE.exe" & if errorlevel 0 taskkill /f /t /im "ShowErrorTE.exe"
goto :eof

:ShowErrorPE
CALL D:\UploadNgError.BAT Kiểm_tra_LCD_GCFEQU_LCD测试 FAIL
cd /d %~dp0
start D:\ShowErrorNew\ShowErrorPE.exe "Test :%name%" %1 %2
ping 127.0.0.1 -n 20
tasklist|find /i "ShowErrorTE.exe" & if errorlevel 0 taskkill /f /t /im "ShowErrorPE.exe"
goto :eof