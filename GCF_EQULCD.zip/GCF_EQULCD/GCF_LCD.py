﻿# ===========================================================================================
# Source = GCF_LCD.py
#
# (C) 2021 Wistron, Inc.
#
# function description
#
# Ver  Date        Programmer      Notes
# ---  ----------  --------------  ---------------------------------------------------------
# 000  11/02/2021  salam cui         Initial Release
# ===========================================================================================
import sys
import time
import os
import re

sys.path.append("D://pythonPyc")
import TestApi
import FileApi


def GetLocalLCD():
    strReturnPix = ''
    try:
        strFind = TestApi.RunCommandStrByKey('wEDID64.exe', 'Max. Resolution')
        if bool(strFind):
            write_log('GetLocalLCD Pixcel info: ', strFind)
            s1, s2 = strFind.split(':')
            s2 = s2.replace(' ', '')
            strReturnPix = s2
        else:
            write_log('GetLocalLCD Pixcel fail!!')

    except Exception as ex:
        write_log('GetLocalLCD except error: ' + str(ex))

    return strReturnPix


def write_log(info, details=None):
    current_time = time.strftime('%m/%d/%Y %X', time.localtime())
    content_log_path = os.path.abspath(os.path.dirname(sys.argv[0]))
    script_name = os.path.basename(__file__).split('.')[0]
    LowDataName = os.path.join(content_log_path, script_name + '.TST')
    print(info)
    if details:
        log = '[%s %s] %s\n%s\n' % (current_time, script_name, info, details)
    else:
        log = '[%s %s] %s\n' % (current_time, script_name, info)
    with open(LowDataName, 'a') as f:
        f.write(log)
        f.flush()
    sys.stdout.flush()


if __name__ == '__main__':
    os.chdir(os.path.abspath(os.path.dirname(sys.argv[0])))
    TestItem = os.path.basename(__file__).split('.')[0]
    PathLog = 'd:\\log'
    logName = TestItem + '.log'
    InfoName = 'D:\\SFCS\\Info.bat'
    GetGcfName = 'D:\\BURNIN\\GCFEQU\\GCF2SIZE.LOG'
    dict_gcf = dict()
    dict_SFCS = dict()
    sys.exit(0)
    write_log('Start Test: ' +TestItem)
    try:  # check info.bat
        dict_SFCS=TestApi.SfcsFile2Dict(InfoName) # check info.bat
        if not bool(dict_SFCS):
            write_log(InfoName + ' not be found or is error!')
            TestApi.showerrorNew(TestItem, 'TENG01')
            sys.exit(1)
        else:
            sPPID=dict_SFCS.get('SFCSPPID')
            if not bool(sPPID):
                write_log(InfoName + ' no SFCSPPID!')
                TestApi.showerrorNew(TestItem, 'TENG01')
                sys.exit(1)

    except Exception as e:
        write_log('check info.bat Exception error: '+ str(e))
        FileApi.CreateNewFile('ERROR.INI', '[TENG99]', str(e))
        TestApi.showerrorNew(TestItem, 'TENG99', 'ERROR.INI')
        sys.exit(1)

    # sPPID3=sPPID[0:3] #check 481 or 491
    if (sPPID.strip().startswith('481')) or (sPPID.strip().startswith('491')):
        write_log('This mode is piolt run!')
        sys.exit(0)

    try:  # check GCF2SIZE.log and check LCD
        dict_gcf = TestApi.SfcsFile2Dict(GetGcfName)  #
        if not bool(dict_gcf):
            write_log(GetGcfName + ' not be found or is error!')
            TestApi.showerrorNew(TestItem, 'TENG02')
            sys.exit(1)
        else:
            Web_LCD = dict_gcf.get('WEB_LCD_PIXEL')  # WEB_LCD
            if not bool(Web_LCD):
                write_log('Get Web LCD fail....')
                TestApi.showerrorNew(TestItem, 'TENG02')
                sys.exit(1)

            strLocalP = GetLocalLCD() # get local lcd
            if not bool(strLocalP):
                TestApi.showerrorNew(TestItem, 'TENG03')
                sys.exit(1)

            if not re.search(strLocalP, Web_LCD, re.IGNORECASE):
                write_log('GCF LCD Check Fail!!')
                TestApi.showerrorNew(TestItem, 'PDNG01')
                sys.exit(1)

    except Exception as e:
        write_log('except error: ' + str(e))
        FileApi.CreateNewFile('ERROR.INI', '[TENG99]', str(e))
        TestApi.showerrorNew(TestItem, 'TENG99', 'ERROR.INI')
        sys.exit(1)

    write_log('GCF LCD CHECK OK')
    sys.stdout.flush()
    sys.exit(0)
