# ===========================================================================================
# Source = Smart_S3.py
#
# (C) 2021 Wistron, Inc.
#
# MS Test
#
# Ver  Date        Programmer          Notes
# ---  ----------  --------------      ---------------------------------------------------------
# 000  07/20/2021  Logan Jiang         Initial Release
# ===========================================================================================
import sys
import time
import os
sys.path.append("D://pythonPyc")
import TestApi
import FileApi


if __name__ == '__main__':
    os.chdir(os.path.abspath(os.path.dirname(sys.argv[0])))
    TestItem = os.path.basename(__file__).split('.')[0]
    PathLog = 'd:\\log'
    logName = TestItem + '.log'

    acount=0
    MScmd='pwrtest.exe /cs /p:150 /d:150 /c:1'
    try:
        while acount < 10 :
            time.sleep(120)
            TestApi.RunCommandOutCode(MScmd)
            time.sleep(150)
            acount += 1

    except Exception as e:
        sys.stdout.flush()
        FileApi.CreateNewFile('ERROR.INI', '[TENG99]', str(e))
        TestApi.showerrorNew(TestItem, 'TENG99', 'ERROR.INI')
        sys.exit(1)

    print('IDLE Test PASS')
    write_log('IDLE test PASS!, MS Cycle:{}'.format(acount))
    sys.stdout.flush()
    sys.exit(0)
