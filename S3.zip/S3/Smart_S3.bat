::-------------------------Set Env-------------------------------------
@echo off
:start
set retry_cycle=5
set name=%~n0
set spec1=0
set spec2=0
set spec3=0
set ERR_CODE=000000
cd /d %~dp0
call D:\Log\TestLog.bat start %name% %spec1% %spec2% %spec3% %ERR_CODE%
::-----------------------MTDL INT-----------------------------------------
set Cmdline="pwrtest64.exe /cs /p:90 /d:90 /c:20"
set BatchFile=%~dp0%name%.Bat
set Function=test
set Process=mfg
set Type="Power State"
set TestID=0X1A00
set TestID1=NA
set TestID2=NA
set TestResponse="S3/CS/MS Test Passed"
set TestResponse1="test pass"
set TestResponse2="test pass"
CALL D:\BURNIN\NEWMTDL\GetNowTime.bat
set StartTime=%TimeFormat%
cd /d %~dp0
::-----------------------MTDL INT-----------------------------------------
::-------------------------Function Test-------------------------------
if exist D:\NewCommon\Common\UUT_New\Special_Item.bat start /w D:\NewCommon\Common\UUT_New\Special_Item.bat WatchDog_S3
@echo on
set CurDrv=%~dp0

:S3
REM ======SFCS S3 SMART START========
SET LEVEL_S=1
SET S3QTY=3
CALL D:\BURNIN\SMART\StartSMART.BAT S3
SET /A S3QTY=%S3QTY%*%LEVEL_S%
IF %S3QTY% EQU 0 (SET /A S3QTY=1)
cd /d %~dp0

CALL S3.BAT %S3QTY%

REM =======END S3 SMART===============
CALL D:\BURNIN\SMART\EndSMART.BAT S3 OK
REM =======END S3 SMART===============


goto pass
::-------------------------Result--------------------------------------
:FAIL
CALL D:\UploadNgError.BAT Kiểm_tra_chế_độ_Modern_Standby_ModenstandBY测试 FAIL
cd /d %~dp0
call D:\ERR_CODE\Set_Error.bat
call D:\ERR_CODE\ERR_CODE.bat %ERR_CODE%
if errorlevel 1 goto start
call D:\log\testlog.bat fail %name% %spec1% %spec2% %spec3% %ERR_CODE%
exit /b 1

:PASS
CALL D:\UploadNgError.BAT Kiểm_tra_chế_độ_Modern_Standby_ModenstandBY测试 PASS
cd /d %~dp0
::--------------------------Creat MTDL INI------------------------------------------
set name=%~n0
CD /D D:\BURNIN\NEWMTDL\RUNIN
IF EXIST %name%.INI DEL %name%.INI
CALL BASE_MDTL_INI.BAT %StartTime% %CmdLine% %BatchFile% %Function% %Process% %Type%

DoIni4MTDL.exe "%name%.INI" TestID %TestID% 	
DoIni4MTDL.exe "%name%.INI" TestResponse %TestResponse%

IF @%TestID1%==@NA GOTO SET_ID_END
DoIni4MTDL.exe "%name%.INI" TestID %TestID1%
DoIni4MTDL.exe "%name%.INI" TestResponse %TestResponse1%

IF @%TestID2%==@NA GOTO SET_ID_END
DoIni4MTDL.exe "%name%.INI" TestID %TestID2%
DoIni4MTDL.exe "%name%.INI" TestResponse %TestResponse2%

:SET_ID_END
cd /d %~dp0
::--------------------------Creat MTDL INI------------------------------------
call D:\log\testlog.bat pass %name% %spec1% %spec2% %spec3% %ERR_CODE%
exit /b 0