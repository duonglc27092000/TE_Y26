# ===========================================================================================
# Source = Smart_S3.py
#
# (C) 2021 Wistron, Inc.
#
# MS Test
#
# Ver  Date        Programmer          Notes
# ---  ----------  --------------      ---------------------------------------------------------
# 000  07/20/2021  Logan Jiang         Initial Release
# ===========================================================================================
import sys
import time
import os
sys.path.append("D://pythonPyc")
import TestApi
import FileApi

def write_log(info, details=None):
    current_time = time.strftime('%m/%d/%Y %X', time.localtime())
    content_log_path = os.path.abspath(os.path.dirname(sys.argv[0]))
    script_name = os.path.basename(__file__).split('.')[0]
    LowDataName = os.path.join(content_log_path, script_name + '.TST')
    print(info)
    if details:
        log = '[%s %s] %s\n%s\n' % (current_time, script_name, info, details)
    else:
        log = '[%s %s] %s\n' % (current_time, script_name, info)
    with open(LowDataName, 'a') as f:
        f.write(log)
        f.flush()
    sys.stdout.flush()

if __name__ == '__main__':
    os.chdir(os.path.abspath(os.path.dirname(sys.argv[0])))

    # Init MTDL log data
    PathMTDL = "D:\\BURNIN\\NEWMTDL\\RUNIN"
    TestItem = os.path.basename(__file__).split('.')[0]
    StartTime = (time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())) + "-05:00"
    iniName = TestItem + '.ini'
    PathLog = 'd:\\log'
    logName = TestItem + '.log'

    dict_Base = dict()
    dict_Base['StartTime'] = StartTime
    dict_Base['TestItem'] = TestItem
    dict_Base['Cmdline'] = 'pwrtest.exe'  # change...
    dict_Base['OS'] = '22621.885'
    dict_Base['BatchFile'] = sys.argv[0]
    dict_Base['Function'] = 'test'  # change...
    dict_Base['Process'] = 'mfg'  # change...
    dict_Base['type'] = 'Power_board'  # change...
    dict_Base['TestResult'] = 'PASS'
    dict_Base['EndTime'] = StartTime
    dict_Base['TestID'] = '0X1A00'  # change...
    dict_Base['TestResponse'] = 'Modern standby test passed'  # change...
    dict_Base['TestResponse1'] = 'test pass'  # change...
    # end init MTDL log data

    acount=0
    MScmd='pwrtest64.exe /cs /p:90 /d:90 /c:1'
    try:
        while acount < 10 :
            TestApi.RunCommandOutCode(MScmd)
            time.sleep(150)
            acount += 1

        EndTime = (time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())) + "-05:00"
        dict_Base["EndTime"] = EndTime
        if os.path.exists(iniName):
            os.remove(iniName)
        else:
            pass
        FileApi.DoIni4MTDL(iniName, dict_Base)
        os.system('copy ' + iniName + ' ' + PathMTDL + ' /y')
        # MTDL end

    except Exception as e:
        sys.stdout.flush()
        FileApi.CreateNewFile('ERROR.INI', '[TENG99]', str(e))
        TestApi.showerrorNew(TestItem, 'TENG99', 'ERROR.INI')
        sys.exit(1)
    try: # Do Log file
        if os.path.exists(logName):
            os.remove(logName)
        dict_Base['StandValue']='MS cycle:{}次'.format(acount) # change....
        dict_Base['TestValue']='MS cycle:{}次'.format(acount) # change....
        dict_Base['GapValue'] = 'NA' # change....
        FileApi.DoIni4MTDL(logName,dict_Base)
        os.system('copy ' + logName + ' ' + PathLog + ' /y')
    except Exception as e:
        print(str(e))
        sys.stdout.flush()
        FileApi.CreateNewFile('ERROR.INI','[TENG98]',str(e))
        TestApi.showerrorNew(TestItem,'TENG98','ERROR.INI')
        sys.exit(1)
    # Do Log file
    print('MS Test PASS')
    write_log('S3 test PASS!, MS Cycle:{}'.format(acount))
    sys.stdout.flush()
    sys.exit(0)
